# Gmail Terminal UI Extension

Transform your Gmail interface into a retro, terminal-style experience inspired by classic computing aesthetics. 

---

## Table of Contents

- [Introduction](#introduction)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Creating the `manifest.json`](#creating-the-manifestjson)
- [Contributing](#contributing)
- [License](#license)
- [Acknowledgments](#acknowledgments)

---

## Introduction

The Gmail Terminal UI Extension revamps your Gmail experience by replacing the default interface with a fully stylized, terminal-inspired shell. All emails are fetched directly from the Gmail API, bypassing Gmail's own rendering and giving you full control over layout and theme.

---

## Features

- **Retro Terminal Design**: Fallout-style green-on-black interface with VT323 terminal font.
- **Custom Inbox UI**: Email subjects and senders rendered as interactive terminal cards.
- **Email Viewer**: Clicking an email loads the message body directly using the Gmail API.
- **Bypass Gmail DOM**: No reliance on Gmail’s markup; fully client-controlled.
- **Search Support**: Filter logs (emails) using Gmail's search operators.
- **OAuth2 Integration**: Uses `chrome.identity` for secure, in-browser auth.

---

## Installation

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/crouchbindcommit/fallout-gmail.git
   ```

2. **Navigate into the Project**:
   ```bash
   cd fallout-gmail
   ```

3. **Create Your `manifest.json`**  
   *(See below for instructions.)*

4. **Load into Chrome**:
   - Go to `chrome://extensions/`
   - Enable **Developer Mode**
   - Click **Load unpacked**
   - Select the folder you cloned

---

## Usage

- When you open Gmail, the extension will load automatically.
- Your inbox will display as a list of logs in a stylized green terminal UI.
- Clicking an email opens a fully custom view (`#vaultlog/<id>`) showing the body.
- Use the `<< Back to Inbox` button to return to the main terminal view.
- Use the log search input to query emails (e.g., `from:boss label:important`).

---

## Creating the `manifest.json`

To keep credentials private, the actual `manifest.json` is excluded from version control. You’ll need to create your own.

### 1. Create a file called `manifest.json` in the root of your project.

### 2. Paste this inside:

```json
{
  "manifest_version": 3,
  "name": "Gmail Terminal UI Extension",
  "version": "1.0.0",
  "description": "Transform your Gmail interface into a retro, terminal-style experience.",
  "icons": {
    "16": "icons/icon16.png",
    "32": "icons/icon32.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  },
  "permissions": [
    "storage",
    "identity",
    "scripting",
    "activeTab"
  ],
  "host_permissions": [
    "https://mail.google.com/"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": ["https://mail.google.com/*"],
      "js": ["content.js"]
    }
  ],
  "action": {
    "default_popup": "popup.html",
    "default_icon": {
      "16": "icons/icon16.png",
      "32": "icons/icon32.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  },
  "oauth2": {
    "client_id": "YOUR_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/gmail.readonly",
      "https://www.googleapis.com/auth/gmail.send",
      "https://www.googleapis.com/auth/gmail.compose",
      "https://www.googleapis.com/auth/gmail.modify"
    ]
  }
}
```

> Replace `YOUR_CLIENT_ID` with your actual OAuth2 client ID from the Google Developer Console.

### 3. Save and reload the extension.

---

## Contributing

We welcome contributions! To contribute:

1. Fork the Repository.
2. Create a New Branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. Make Your Changes and Commit:
   ```bash
   git commit -m "Add your feature"
   ```
4. Push to Your Branch:
   ```bash
   git push origin feature/your-feature-name
   ```
5. Create a Pull Request.

Please ensure your code adheres to the project's standards and includes appropriate documentation.

---

## License

This project is licensed under the [MIT License](LICENSE).

---

## Acknowledgments

- **GIF Attribution**: The GIF used in this project is sourced from [gifer.com](https://gifer.com/en/XQZ0). All rights and credits belong to the original creator.
- **Inspiration**: Inspired by classic terminal interfaces and the Fallout franchise's retro-futuristic aesthetic.
- **NOTE**: this project is not affiliated or sponsored by Bethesda or Obsidion in any way. This is purely fan made.
# Gmail Terminal UI Extension

Transform your Gmail interface into a retro, terminal-style experience inspired by classic computing aesthetics.

---

## Table of Contents

- [Introduction](#introduction)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Creating the `manifest.json`](#creating-the-manifestjson)
- [Contributing](#contributing)
- [License](#license)
- [Acknowledgments](#acknowledgments)

---

## Introduction

The Gmail Terminal UI Extension revamps your Gmail experience by replacing the default interface with a fully stylized, terminal-inspired shell. All emails are fetched directly from the Gmail API, bypassing Gmail's own rendering and giving you full control over layout and theme.

---

## Features

- **Retro Terminal Design**: Fallout-style green-on-black interface with VT323 terminal font.
- **Custom Inbox UI**: Email subjects and senders rendered as interactive terminal cards.
- **Email Viewer**: Clicking an email loads the message body directly using the Gmail API.
- **Bypass Gmail DOM**: No reliance on Gmail’s markup; fully client-controlled.
- **Search Support**: Filter logs (emails) using Gmail's search operators.
- **OAuth2 Integration**: Uses `chrome.identity` for secure, in-browser auth.

---

## Installation

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/crouchbindcommit/fallout-gmail.git
   ```

2. **Navigate into the Project**:
   ```bash
   cd fallout-gmail
   ```

3. **Create Your `manifest.json`**  
   *(See below for instructions.)*

4. **Load into Chrome**:
   - Go to `chrome://extensions/`
   - Enable **Developer Mode**
   - Click **Load unpacked**
   - Select the folder you cloned

---

## Usage

- When you open Gmail, the extension will load automatically.
- Your inbox will display as a list of logs in a stylized green terminal UI.
- Clicking an email opens a fully custom view (`#vaultlog/<id>`) showing the body.
- Use the `<< Back to Inbox` button to return to the main terminal view.
- Use the log search input to query emails (e.g., `from:boss label:important`).

---

## Creating the `manifest.json`

To keep credentials private, the actual `manifest.json` is excluded from version control. You’ll need to create your own.

### 1. Create a file called `manifest.json` in the root of your project.

### 2. Paste this inside:

```json
{
  "manifest_version": 3,
  "name": "Gmail Terminal UI Extension",
  "version": "1.0.0",
  "description": "Transform your Gmail interface into a retro, terminal-style experience.",
  "icons": {
    "16": "icons/icon16.png",
    "32": "icons/icon32.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  },
  "permissions": [
    "storage",
    "identity",
    "scripting",
    "activeTab"
  ],
  "host_permissions": [
    "https://mail.google.com/"
  ],
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": ["https://mail.google.com/*"],
      "js": ["content.js"]
    }
  ],
  "action": {
    "default_popup": "popup.html",
    "default_icon": {
      "16": "icons/icon16.png",
      "32": "icons/icon32.png",
      "48": "icons/icon48.png",
      "128": "icons/icon128.png"
    }
  },
  "oauth2": {
    "client_id": "YOUR_CLIENT_ID.apps.googleusercontent.com",
    "scopes": [
      "https://www.googleapis.com/auth/gmail.readonly",
      "https://www.googleapis.com/auth/gmail.send",
      "https://www.googleapis.com/auth/gmail.compose",
      "https://www.googleapis.com/auth/gmail.modify"
    ]
  }
}
```

> Replace `YOUR_CLIENT_ID` with your actual OAuth2 client ID from the Google Developer Console.

### 3. Save and reload the extension.

---

## Contributing

We welcome contributions! To contribute:

1. Fork the Repository.
2. Create a New Branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. Make Your Changes and Commit:
   ```bash
   git commit -m "Add your feature"
   ```
4. Push to Your Branch:
   ```bash
   git push origin feature/your-feature-name
   ```
5. Create a Pull Request.

Please ensure your code adheres to the project's standards and includes appropriate documentation.

---

## License

This project is licensed under the [MIT License](LICENSE).

---

## Acknowledgments

- **GIF Attribution**: The GIF used in this project is sourced from [gifer.com](https://gifer.com/en/XQZ0). All rights and credits belong to the original creator.
- **Inspiration**: Inspired by classic terminal interfaces and the Fallout franchise's retro-futuristic aesthetic.
-- **NOTE**: This is completely fan made and not affiliated with Obsidion or Bethesda in any way.